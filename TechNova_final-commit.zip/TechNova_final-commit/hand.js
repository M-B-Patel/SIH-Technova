const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const cors = require('cors');

const app = express();
const PORT = 3000;

// --- Middleware ---
// Enable CORS to allow requests from your front-end
app.use(cors());
// Parse incoming JSON data (from form submissions)
app.use(express.json());

// --- MongoDB Connection ---
// IMPORTANT: Replace this with your own MongoDB connection string!
const MONGO_URI = 'mongodb+srv://rahulbhoiya_db_user:iIqPV0kCQNyyC94Y@cluster0.vmsaenc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

mongoose.connect(MONGO_URI)
    .then(() => console.log('Successfully connected to MongoDB!'))
    .catch(err => console.error('MongoDB connection error:', err));

// --- User Schema and Model ---
const userSchema = new mongoose.Schema({
    userId: { type: String, required: true, unique: true, trim: true },
    password: { type: String, required: true },
    location: { type: String, required: true },
    bloodGroup: { type: String, required: true }
});

// Hash the password before saving the user model
userSchema.pre('save', async function(next) {
    if (this.isModified('password')) {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
    }
    next();
});

const User = mongoose.model('User', userSchema);

// --- API Routes ---

// 1. REGISTRATION ROUTE
app.post('/register', async (req, res) => {
    try {
        const { userId, password, location, bloodGroup } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ userId });
        if (existingUser) {
            return res.status(400).json({ message: 'User ID already exists. Please choose another.' });
        }

        // Create a new user
        const newUser = new User({ userId, password, location, bloodGroup });
        await newUser.save();

        res.status(201).json({ message: 'User registered successfully!' });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ message: 'Server error during registration.' });
    }
});

// 2. LOGIN ROUTE
app.post('/login', async (req, res) => {
    try {
        const { userId, password } = req.body;

        // Find the user by userId
        const user = await User.findOne({ userId });
        if (!user) {
            return res.status(404).json({ message: 'User ID not found.' });
        }

        // Compare the provided password with the stored hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid password. Please try again.' });
        }

        res.status(200).json({ message: 'Login successful!' });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ message: 'Server error during login.' });
    }
});


// --- Start the Server ---
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});